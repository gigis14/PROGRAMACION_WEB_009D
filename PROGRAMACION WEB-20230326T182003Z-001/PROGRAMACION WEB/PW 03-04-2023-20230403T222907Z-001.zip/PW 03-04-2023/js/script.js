
//Funcion
function verDatos() {
    var cantidad = 2;
    var nombres = document.getElementById('nombres').value;
    var apellidos = document.getElementById('apellidos').value;

    //Alt Gr + ]} = comillas invertidas
    ``
    //TEXTO
    var texto = `Tengo ${cantidad} datos del cliente:`;

    // += (texto = texto + algo) : Concatenar texto
    // \n : identar texto
    texto += `\nNombres: ${nombres}`;
    texto += `\nApellidos: ${apellidos}`;

    alert(texto);
}

function sumar(num1,num2) {
    return num1 + num2;
}

function verSuma(){
    var objeto1 = document.getElementById('num1');
    var objeto2 = document.getElementById('num2');

    // parseInt(objeto1.value) = Parsea el objeto1 string a Int para poder sumarlos
    var num1 = parseInt(objeto1.value);
    var num2 = parseInt(objeto2.value);

    var suma = sumar(num1,num2);
    var texto = `La suma es ${suma}`;
    alert(texto);
}

function agrandarLetra() {
    var elementoHTML = document.getElementById('parrafo');
    elementoHTML.style.fontSize = '30px';
    elementoHTML.style.color = 'red';
}

function achicarLetra() {
    var elementoHTML = document.getElementById('parrafo');
    elementoHTML.style.fontSize = '12px';
    elementoHTML.style.color = 'black';
}